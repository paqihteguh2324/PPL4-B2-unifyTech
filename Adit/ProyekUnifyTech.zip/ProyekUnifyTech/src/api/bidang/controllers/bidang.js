'use strict';

/**
 *  bidang controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::bidang.bidang');
