'use strict';

/**
 * bidang router.
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::bidang.bidang');
