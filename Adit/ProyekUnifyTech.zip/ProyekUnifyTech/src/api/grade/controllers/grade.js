'use strict';

/**
 *  grade controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::grade.grade');
