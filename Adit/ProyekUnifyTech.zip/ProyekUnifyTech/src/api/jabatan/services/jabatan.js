'use strict';

/**
 * jabatan service.
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::jabatan.jabatan');
