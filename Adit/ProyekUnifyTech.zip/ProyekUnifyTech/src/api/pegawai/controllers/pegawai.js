'use strict';

/**
 *  pegawai controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::pegawai.pegawai');
