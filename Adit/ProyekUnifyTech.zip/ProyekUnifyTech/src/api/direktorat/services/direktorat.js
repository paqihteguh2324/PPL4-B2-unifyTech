'use strict';

/**
 * direktorat service.
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::direktorat.direktorat');
