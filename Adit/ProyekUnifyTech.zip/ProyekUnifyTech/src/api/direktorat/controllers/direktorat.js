'use strict';

/**
 *  direktorat controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::direktorat.direktorat');
