'use strict';

/**
 *  sub-bidang controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::sub-bidang.sub-bidang');
