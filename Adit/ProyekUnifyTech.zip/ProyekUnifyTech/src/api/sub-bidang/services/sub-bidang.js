'use strict';

/**
 * sub-bidang service.
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::sub-bidang.sub-bidang');
