'use strict';

/**
 * jenjang service.
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::jenjang.jenjang');
