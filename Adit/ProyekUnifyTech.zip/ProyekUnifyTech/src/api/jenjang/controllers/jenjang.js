'use strict';

/**
 *  jenjang controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::jenjang.jenjang');
