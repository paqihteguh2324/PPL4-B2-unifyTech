'use strict';

/**
 *  divisi controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::divisi.divisi');
